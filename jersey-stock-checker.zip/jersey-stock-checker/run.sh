#!/usr/bin/env bash
# Run the checker from source on macOS / Linux (no exe needed).
set -e
cd "$(dirname "$0")"

PY="${PYTHON:-python3}"

echo "Installing dependencies..."
"$PY" -m pip install -r requirements.txt

echo "Installing stealth browser (first run only, ~150MB)..."
"$PY" -m patchright install chromium

echo "Starting Jersey Stock Checker..."
"$PY" jersey_checker.py
